The Crowd Safety Intelligence System is an AI-powered platform that ensures public safety during large events like concerts, festivals, and rallies.
It uses real-time video feeds and AI analysis to detect overcrowding, predict risks, and send alerts to authorities for quick action.

Provides real-time alerts for overcrowded zones.

Predicts risk areas to prevent stampedes or accidents.

Simple and responsive ReactJS dashboard for monitoring.
